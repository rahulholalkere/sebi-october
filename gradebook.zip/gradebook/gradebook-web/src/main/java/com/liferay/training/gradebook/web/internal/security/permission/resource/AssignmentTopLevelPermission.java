package com.liferay.training.gradebook.web.internal.security.permission.resource;

import com.liferay.portal.kernel.security.permission.PermissionChecker;
import com.liferay.portal.kernel.security.permission.resource.PortletResourcePermission;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * This Class Represents As A Helper Class In Portlet Module For Checking Top-Level Permissions (Specially For Adding A New Assignment)
 * @author hgrahul
 */
@Component(immediate = true)
public class AssignmentTopLevelPermission {
	public static boolean contains(PermissionChecker permissionChecker, long groupId, String actionKey) {
		return assignmentPortletResourcePermission.contains(permissionChecker, groupId, actionKey);
	}
	
	@Reference(target = "(resource.name=com.liferay.training.gradebook.model)", unbind = "-")
	protected void setAssignmentPortletResourcePermission(PortletResourcePermission portletResourcePermission) {
		assignmentPortletResourcePermission = portletResourcePermission;
	}
	
	private static PortletResourcePermission assignmentPortletResourcePermission;
}
